---
layout: post
category: Rants
title: Why leaving university was one of the best things I've done
published: draft
---

I didn't do to well at university. For some reason I decided to take a music course. Wasn't technical - was mostly theory which wasn't my strong point.

I grew up in rural Wales - Brecon - where computer science isn't on the forefront of peoples minds. The high school only offered the tradition subjects (I opted for Maths, Chemistry and Music). For the more adventurous you could go to the local collage and get a BTec in masonry...

<!--excerpt-->

It wasn't until I left Brecon that I really started to get to know the true magnitude of the options that were available to me and after a painful year of Music I decided to call it a day. In hindsight this is when I should have signed up for a CS degree but what 19 year old me hadn't discovered programming yet. instead I did what any self respecting drop out would have done. I got a job in a call centre. Now one thing led to another and fast forward a year or so and I was doing localistion processing for a translation company. This is a dull as it sounds but it taught me a lot of valuble lessons.

1. RegEx - whether this is a blessing or a hindrance I am yet to find out but for over a year I RegExed the crap out of those files.
2. C# - RegEx is great but there is only so far you can go. My boss at the time introduced me to LinqPad so I got myself a C# book and never looked back.
3. PM's - Learning how to communicate complex issues to non techies has helped me out no end since then.

The next thing I know I've been promoted and I'm writing C# code for a living! Fast forward a year and I'm a full blown Software Developer!

That was four years ago and is not the point of this post. Since then I have always felt somewhat lacking compared to my honoured peers and have gone out of my way learn new techniques, frameworks and standards. It is this underlying insecurity that one day my employers will turn around and say "wait a minute - you don't have a degree" that pushes me to consistently push myself to my limit.

I'm interested to see what other people in the industry think to this, especially those who have the degrees and can see it from the other side. Do you think there is a clear difference between the educated and the self taught developer? What are the pro's and con's?