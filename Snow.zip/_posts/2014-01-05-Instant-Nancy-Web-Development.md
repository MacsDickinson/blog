---
layout: post
category: Nancy
title: Instant Nancy Web Development with Christian Horsdal
published: draft
---

I've been lucky enough to get my mits on a copy of [Christian Horsdal][0]'s new book [Instant Nancy Web Development][1]. 

<!--excerpt-->

   [0]: http://twitter.com/chr_horsdal
   [1]: http://bit.ly/1bIK5hp